$(function(){

	/*$('.hd_more').click(function(){ 
	    $('.hd_menu').addClass('active');
	    $('.pop_bg').show();
    });
    $('.pop_bg').click(function(){ 
        $('.hd_menu').removeClass('active');
        $('.pop_bg').hide();
    });
    
    //
    $(".tabmenu .lk").click(function(){
        $(this).addClass("cur").siblings().removeClass("cur");
        
        var index=$(this).parent('.tabmenu').children('.lk').index(this);    
        
        $(this).parents(".tabmenu").siblings(".tabwrap").children(".module").eq(index).show().siblings().hide();
        
    });*/
    //多图商品
    /*$("#add").click(function() {
        var num = parseInt($("#bookNum").val()) || 0;
        $("#bookNum").val(num + 1);
    });
    //减去
    $("#sub").click(function() {
        var num = parseInt($("#bookNum").val()) || 0;
        num = num - 1;
        num = num < 1 ? 1 : num;
        $("#bookNum").val(num);
    });*/



});














